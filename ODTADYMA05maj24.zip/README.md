Jedná sa o prezentačný web (nie e-shop) vytvorený za účelom ukázať ľuďom, čo má farmársky obchod Odtadyma na predajni vo Vsetíne. 

Použité sú kódovacie jazyky HTML a CSS a základy JavaScriptu. 

Do budúcna budem pridávať na web ďalšie JS funkcionality (napr skrytie menu pri scroll down a naopak zobrazenie pri scroll up, odzoomovanie hlavnej foto po načítaní, administrácia webu, preklikávacie aktuality na HP, či formulár)